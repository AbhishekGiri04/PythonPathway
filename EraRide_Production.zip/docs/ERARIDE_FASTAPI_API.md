# EraRide FastAPI API Map

Base URL: `http://localhost:8000/api/v1`

## Auth
- `POST /auth/otp/request`
- `POST /auth/otp/verify`
- `POST /auth/register`
- `POST /auth/login`

## Users
- `GET /users/me`
- `PUT /users/me/vehicle`
- `GET /users/driver/{driver_id}/masked-contact`

## Rides
- `POST /rides`
- `GET /rides`
- `GET /rides/mine`
- `PATCH /rides/{ride_id}/cancel`

## Bookings
- `POST /bookings`
- `GET /bookings/mine`
- `PATCH /bookings/{booking_id}/cancel`

## Complaints
- `POST /complaints`
- `GET /complaints/mine`
- `GET /complaints` (admin)
- `PATCH /complaints/{complaint_id}` (admin)

## Payments
- `POST /payments`

## Chat
- `POST /chat/room/{ride_id}`
- `GET /chat/room/{room_id}/messages`
- `POST /chat/message`
- `WS /chat/ws/{room_id}?token=<jwt>`

## Admin
- `GET /admin/drivers/pending`
- `PATCH /admin/drivers/{driver_id}/verify`
- `PATCH /admin/users/{user_id}/suspend`
