# EraRide FastAPI Backend

## Features
- Email-domain restricted OTP auth (`@gehu.ac.in`, `@geu.ac.in`)
- JWT auth with role-based authorization
- Driver verification workflow (admin approval)
- Rides + booking with Redis seat lock
- Complaint system
- Chat room + WebSocket messaging
- Cash + optional Stripe payment intent support
- Redis rate limiting, ride list caching, and presence tracking

## Run Locally
```bash
cp .env.example .env
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

## Run with Docker
```bash
docker compose -f ../docker-compose.eraride.yml up --build
```

## Seed Admin
```bash
python -m scripts.seed_admin
```
Default admin: `admin@gehu.ac.in` / `Admin@123`

## API Docs
- Swagger: `http://localhost:8000/docs`
- Health: `http://localhost:8000/health`
