# EraRide MVP (Flutter + FastAPI)

This implementation adds a production-oriented MVP for a student-only campus carpool platform:
- Frontend: Flutter + Riverpod (`frontend_flutter`)
- Backend: FastAPI + async SQLAlchemy (`backend_fastapi`)
- Database: PostgreSQL
- Cache/Lock: Redis (seat locking + caching + rate limiting + presence)
- Payment: cash by default, optional Stripe payment intent
- Chat: WebSocket ride-room messaging

## Project Structure
- `backend_fastapi`: FastAPI backend
- `frontend_flutter`: Flutter mobile app
- `docker-compose.eraride.yml`: Local infra (Postgres, Redis, FastAPI)

## Quick Start
1. Start backend stack
```bash
docker compose -f docker-compose.eraride.yml up --build
```

2. (Optional) Seed admin
```bash
cd backend_fastapi
python -m scripts.seed_admin
```

3. Run Flutter app
```bash
cd frontend_flutter
flutter pub get
flutter run
```

## Auth Rules
- Allowed domains: `@gehu.ac.in`, `@geu.ac.in`
- OTP required before registration (MVP OTP logs in backend console)
- JWT sessions with role checks

## Core API Endpoints
- Auth: `/api/v1/auth/*`
- Users/driver docs: `/api/v1/users/*`
- Rides: `/api/v1/rides/*`
- Bookings: `/api/v1/bookings/*`
- Complaints: `/api/v1/complaints/*`
- Payments: `/api/v1/payments/*`
- Chat: `/api/v1/chat/*`, websocket `/api/v1/chat/ws/{room_id}`
- Admin: `/api/v1/admin/*`

## Delivery Zip
Use this command from repo root:
```bash
zip -r EraRide_MVP_Flutter_FastAPI.zip backend_fastapi frontend_flutter docker-compose.eraride.yml README_FASTAPI_FLUTTER.md
```
