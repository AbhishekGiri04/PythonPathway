import 'package:flutter/material.dart';

ThemeData buildTheme() {
  const primary = Color(0xFF0B5ED7);
  const background = Color(0xFFF4F8FF);

  return ThemeData(
    useMaterial3: true,
    colorScheme: ColorScheme.fromSeed(seedColor: primary, primary: primary, background: background),
    scaffoldBackgroundColor: background,
    appBarTheme: const AppBarTheme(backgroundColor: primary, foregroundColor: Colors.white),
    cardTheme: CardTheme(
      elevation: 1,
      color: Colors.white,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
    ),
    inputDecorationTheme: InputDecorationTheme(
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
      filled: true,
      fillColor: Colors.white,
    ),
  );
}
