class AppConstants {
  static const String appName = 'EraRide';
  static const String baseUrl = 'http://10.0.2.2:8000/api/v1';
}
