import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../services/api_client.dart';

class AdminScreen extends ConsumerStatefulWidget {
  const AdminScreen({super.key});

  @override
  ConsumerState<AdminScreen> createState() => _AdminScreenState();
}

class _AdminScreenState extends ConsumerState<AdminScreen> {
  List<dynamic> pendingDrivers = [];

  Future<void> loadPending() async {
    final response = await ref.read(dioProvider).get('/admin/drivers/pending');
    setState(() => pendingDrivers = response.data as List<dynamic>);
  }

  @override
  void initState() {
    super.initState();
    Future.microtask(loadPending);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Admin Dashboard')),
      body: ListView.builder(
        itemCount: pendingDrivers.length,
        itemBuilder: (context, index) {
          final d = pendingDrivers[index] as Map<String, dynamic>;
          return ListTile(
            title: Text('${d['vehicle_number']} - ${d['model']}'),
            subtitle: Text('Driver ID: ${d['driver_id']}'),
            trailing: Wrap(
              spacing: 8,
              children: [
                ElevatedButton(
                  onPressed: () async {
                    await ref.read(dioProvider).patch('/admin/drivers/${d['driver_id']}/verify', queryParameters: {'approved': true});
                    await loadPending();
                  },
                  child: const Text('Approve'),
                ),
                OutlinedButton(
                  onPressed: () async {
                    await ref.read(dioProvider).patch('/admin/drivers/${d['driver_id']}/verify', queryParameters: {'approved': false});
                    await loadPending();
                  },
                  child: const Text('Reject'),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
