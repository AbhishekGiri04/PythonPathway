import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';

import 'rides_controller.dart';

class RidesScreen extends ConsumerStatefulWidget {
  const RidesScreen({super.key});

  @override
  ConsumerState<RidesScreen> createState() => _RidesScreenState();
}

class _RidesScreenState extends ConsumerState<RidesScreen> {
  final searchCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    Future.microtask(() => ref.read(ridesControllerProvider.notifier).fetchRides());
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(ridesControllerProvider);
    return Scaffold(
      appBar: AppBar(title: const Text('Find Rides')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                Expanded(child: TextField(controller: searchCtrl, decoration: const InputDecoration(labelText: 'Search by area'))),
                const SizedBox(width: 8),
                ElevatedButton(
                  onPressed: () => ref.read(ridesControllerProvider.notifier).fetchRides(fromArea: searchCtrl.text),
                  child: const Text('Search'),
                ),
              ],
            ),
          ),
          if (state.loading) const LinearProgressIndicator(),
          Expanded(
            child: ListView.builder(
              itemCount: state.rides.length,
              itemBuilder: (context, index) {
                final ride = state.rides[index];
                return Card(
                  margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  child: ListTile(
                    title: Text('${ride.fromArea} -> ${ride.toCampus}'),
                    subtitle: Text('${DateFormat('dd MMM hh:mm a').format(DateTime.parse(ride.departureTime))} | Seats: ${ride.availableSeats}/${ride.totalSeats} | Rs ${ride.pricePerSeat.toStringAsFixed(0)}'),
                    trailing: Wrap(
                      spacing: 6,
                      children: [
                        ElevatedButton(
                          onPressed: ride.availableSeats <= 0 ? null : () => ref.read(ridesControllerProvider.notifier).bookRide(ride.id, 1),
                          child: const Text('Book'),
                        ),
                        OutlinedButton(
                          onPressed: () {
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(content: Text('Call placeholder: enabled only after active booking')),
                            );
                          },
                          child: const Text('Call'),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
          if (state.error != null)
            Padding(
              padding: const EdgeInsets.all(10),
              child: Text(state.error!, style: const TextStyle(color: Colors.red)),
            ),
        ],
      ),
    );
  }
}
