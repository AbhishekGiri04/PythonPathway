import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'rides_controller.dart';

class DriverRideScreen extends ConsumerStatefulWidget {
  const DriverRideScreen({super.key});

  @override
  ConsumerState<DriverRideScreen> createState() => _DriverRideScreenState();
}

class _DriverRideScreenState extends ConsumerState<DriverRideScreen> {
  final fromCtrl = TextEditingController();
  final toCtrl = TextEditingController(text: 'GEHU Campus');
  final seatCtrl = TextEditingController(text: '3');
  final priceCtrl = TextEditingController(text: '80');

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Driver - Create Ride')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(controller: fromCtrl, decoration: const InputDecoration(labelText: 'From Area')),
            const SizedBox(height: 8),
            TextField(controller: toCtrl, decoration: const InputDecoration(labelText: 'To Campus')),
            const SizedBox(height: 8),
            TextField(controller: seatCtrl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Seats')),
            const SizedBox(height: 8),
            TextField(controller: priceCtrl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Price per seat')),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: () async {
                await ref.read(ridesControllerProvider.notifier).createRide(
                      fromArea: fromCtrl.text,
                      toCampus: toCtrl.text,
                      departure: DateTime.now().add(const Duration(hours: 1)),
                      seats: int.parse(seatCtrl.text),
                      price: double.parse(priceCtrl.text),
                    );
                if (mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Ride created')));
                }
              },
              child: const Text('Create Ride'),
            ),
            const SizedBox(height: 12),
            const Text('Drivers must be admin-verified before ride creation.'),
          ],
        ),
      ),
    );
  }
}
