import 'package:dio/dio.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../models/app_models.dart';
import '../../services/api_client.dart';

class RidesState {
  final List<Ride> rides;
  final bool loading;
  final String? error;

  const RidesState({this.rides = const [], this.loading = false, this.error});

  RidesState copyWith({List<Ride>? rides, bool? loading, String? error}) {
    return RidesState(rides: rides ?? this.rides, loading: loading ?? this.loading, error: error);
  }
}

class RidesController extends StateNotifier<RidesState> {
  RidesController(this._ref) : super(const RidesState());

  final Ref _ref;

  Future<void> fetchRides({String? fromArea}) async {
    state = state.copyWith(loading: true, error: null);
    try {
      final dio = _ref.read(dioProvider);
      final response = await dio.get('/rides', queryParameters: {'from_area': fromArea});
      final list = (response.data as List<dynamic>).cast<Map<String, dynamic>>().map(Ride.fromJson).toList();
      state = state.copyWith(rides: list, loading: false);
    } on DioException catch (e) {
      state = state.copyWith(loading: false, error: e.response?.data.toString() ?? e.message);
    }
  }

  Future<void> createRide({
    required String fromArea,
    required String toCampus,
    required DateTime departure,
    required int seats,
    required double price,
  }) async {
    final dio = _ref.read(dioProvider);
    await dio.post('/rides', data: {
      'from_area': fromArea,
      'to_campus': toCampus,
      'departure_time': departure.toIso8601String(),
      'total_seats': seats,
      'price_per_seat': price,
    });
    await fetchRides();
  }

  Future<void> bookRide(int rideId, int seats) async {
    final dio = _ref.read(dioProvider);
    await dio.post('/bookings', data: {'ride_id': rideId, 'seats_booked': seats});
    await fetchRides();
  }
}

final ridesControllerProvider = StateNotifierProvider<RidesController, RidesState>((ref) => RidesController(ref));
