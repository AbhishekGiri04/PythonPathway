import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../services/api_client.dart';

class TeacherComplaintScreen extends ConsumerStatefulWidget {
  const TeacherComplaintScreen({super.key});

  @override
  ConsumerState<TeacherComplaintScreen> createState() => _TeacherComplaintScreenState();
}

class _TeacherComplaintScreenState extends ConsumerState<TeacherComplaintScreen> {
  final descCtrl = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Teacher Complaints')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: descCtrl,
              maxLines: 5,
              decoration: const InputDecoration(labelText: 'Complaint details'),
            ),
            const SizedBox(height: 12),
            ElevatedButton(
              onPressed: () async {
                await ref.read(dioProvider).post('/complaints', data: {'description': descCtrl.text});
                if (mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Complaint filed')));
                }
              },
              child: const Text('Submit Complaint'),
            )
          ],
        ),
      ),
    );
  }
}
