import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../services/api_client.dart';

class MyBookingsScreen extends ConsumerStatefulWidget {
  const MyBookingsScreen({super.key});

  @override
  ConsumerState<MyBookingsScreen> createState() => _MyBookingsScreenState();
}

class _MyBookingsScreenState extends ConsumerState<MyBookingsScreen> {
  List<dynamic> bookings = [];

  Future<void> load() async {
    final response = await ref.read(dioProvider).get('/bookings/mine');
    setState(() => bookings = response.data as List<dynamic>);
  }

  @override
  void initState() {
    super.initState();
    Future.microtask(load);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('My Bookings')),
      body: RefreshIndicator(
        onRefresh: load,
        child: ListView.builder(
          itemCount: bookings.length,
          itemBuilder: (context, index) {
            final b = bookings[index] as Map<String, dynamic>;
            return ListTile(
              title: Text('Ride #${b['ride_id']} | Seats ${b['seats_booked']}'),
              subtitle: Text('Status: ${b['status']}'),
              trailing: (b['status'] == 'booked')
                  ? TextButton(
                      onPressed: () async {
                        await ref.read(dioProvider).patch('/bookings/${b['id']}/cancel');
                        await load();
                      },
                      child: const Text('Cancel'),
                    )
                  : null,
            );
          },
        ),
      ),
    );
  }
}
