import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../services/api_client.dart';
import '../../services/chat_service.dart';
import '../auth/auth_controller.dart';

class ChatScreen extends ConsumerStatefulWidget {
  const ChatScreen({super.key});

  @override
  ConsumerState<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends ConsumerState<ChatScreen> {
  final roomCtrl = TextEditingController();
  final msgCtrl = TextEditingController();
  final chatService = ChatService();
  final messages = <String>[];

  StreamSubscription? _sub;

  void connect() {
    final token = ref.read(authControllerProvider).user?.token;
    final roomId = int.tryParse(roomCtrl.text);
    if (token == null || roomId == null) return;
    final channel = chatService.connect(roomId: roomId, token: token);
    _sub = channel.stream.listen((event) {
      final map = chatService.decode(event);
      setState(() => messages.add('${map['sender_id']}: ${map['message']}'));
    });
  }

  Future<void> send() async {
    final roomId = int.tryParse(roomCtrl.text);
    if (roomId == null) return;
    await ref.read(dioProvider).post('/chat/message', data: {'room_id': roomId, 'message': msgCtrl.text});
    msgCtrl.clear();
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Ride Chat')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(controller: roomCtrl, decoration: const InputDecoration(labelText: 'Room ID')),
            const SizedBox(height: 8),
            ElevatedButton(onPressed: connect, child: const Text('Connect')),
            const Divider(height: 24),
            Expanded(
              child: ListView(
                children: messages.map((e) => ListTile(title: Text(e))).toList(),
              ),
            ),
            Row(
              children: [
                Expanded(child: TextField(controller: msgCtrl, decoration: const InputDecoration(labelText: 'Message'))),
                IconButton(onPressed: send, icon: const Icon(Icons.send)),
              ],
            )
          ],
        ),
      ),
    );
  }
}
