const roleSelectionNote = 'Roles: Driver, Rider, Teacher, Admin (admin seeded via backend script).';
