import 'package:dio/dio.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../models/app_models.dart';
import '../../services/api_client.dart';
import '../../services/auth_storage.dart';

final authStorageProvider = Provider<AuthStorage>((_) => AuthStorage());

class AuthState {
  final AppUser? user;
  final bool loading;
  final String? error;

  const AuthState({this.user, this.loading = false, this.error});

  AuthState copyWith({AppUser? user, bool? loading, String? error}) {
    return AuthState(user: user ?? this.user, loading: loading ?? this.loading, error: error);
  }
}

class AuthController extends StateNotifier<AuthState> {
  AuthController(this._ref) : super(const AuthState());

  final Ref _ref;

  Future<void> bootstrap() async {
    final stored = await _ref.read(authStorageProvider).loadUser();
    if (stored != null) {
      state = state.copyWith(user: stored);
    }
  }

  Future<void> requestOtp(String email) async {
    final dio = _ref.read(dioProvider);
    await dio.post('/auth/otp/request', data: {'email': email});
  }

  Future<void> verifyOtp(String email, String otp) async {
    final dio = _ref.read(dioProvider);
    await dio.post('/auth/otp/verify', data: {'email': email, 'otp': otp});
  }

  Future<void> register({
    required String email,
    required String fullName,
    required String password,
    required String role,
  }) async {
    state = state.copyWith(loading: true, error: null);
    try {
      final dio = _ref.read(dioProvider);
      final response = await dio.post('/auth/register', data: {
        'email': email,
        'full_name': fullName,
        'password': password,
        'role': role,
      });
      final data = response.data as Map<String, dynamic>;
      final user = AppUser(id: data['user_id'] as int, email: email, role: data['role'] as String, token: data['access_token'] as String);
      await _ref.read(authStorageProvider).saveUser(user);
      state = state.copyWith(user: user, loading: false);
    } on DioException catch (e) {
      state = state.copyWith(loading: false, error: e.response?.data.toString() ?? e.message);
    }
  }

  Future<void> login(String email, String password) async {
    state = state.copyWith(loading: true, error: null);
    try {
      final dio = _ref.read(dioProvider);
      final response = await dio.post('/auth/login', data: {'email': email, 'password': password});
      final data = response.data as Map<String, dynamic>;
      final user = AppUser(id: data['user_id'] as int, email: email, role: data['role'] as String, token: data['access_token'] as String);
      await _ref.read(authStorageProvider).saveUser(user);
      state = state.copyWith(user: user, loading: false);
    } on DioException catch (e) {
      state = state.copyWith(loading: false, error: e.response?.data.toString() ?? e.message);
    }
  }

  Future<void> logout() async {
    await _ref.read(authStorageProvider).clear();
    state = const AuthState();
  }
}

final authControllerProvider = StateNotifierProvider<AuthController, AuthState>((ref) {
  return AuthController(ref);
});
