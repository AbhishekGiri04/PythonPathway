import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'auth_controller.dart';
import 'role_selection_note.dart';

class OtpRegisterScreen extends ConsumerStatefulWidget {
  const OtpRegisterScreen({super.key});

  @override
  ConsumerState<OtpRegisterScreen> createState() => _OtpRegisterScreenState();
}

class _OtpRegisterScreenState extends ConsumerState<OtpRegisterScreen> {
  final emailCtrl = TextEditingController();
  final otpCtrl = TextEditingController();
  final nameCtrl = TextEditingController();
  final passCtrl = TextEditingController();
  String role = 'rider';
  bool otpVerified = false;
  String info = '';

  @override
  Widget build(BuildContext context) {
    final auth = ref.watch(authControllerProvider);
    return Scaffold(
      appBar: AppBar(title: const Text('OTP Registration')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(controller: emailCtrl, decoration: const InputDecoration(labelText: 'College Email')),
            const SizedBox(height: 8),
            ElevatedButton(
              onPressed: () async {
                await ref.read(authControllerProvider.notifier).requestOtp(emailCtrl.text.trim());
                setState(() => info = 'OTP sent. For MVP, check backend logs.');
              },
              child: const Text('Request OTP'),
            ),
            const SizedBox(height: 8),
            TextField(controller: otpCtrl, decoration: const InputDecoration(labelText: 'OTP')),
            ElevatedButton(
              onPressed: () async {
                await ref.read(authControllerProvider.notifier).verifyOtp(emailCtrl.text.trim(), otpCtrl.text.trim());
                setState(() {
                  otpVerified = true;
                  info = 'OTP verified';
                });
              },
              child: const Text('Verify OTP'),
            ),
            const Divider(height: 28),
            TextField(controller: nameCtrl, decoration: const InputDecoration(labelText: 'Full Name')),
            const SizedBox(height: 8),
            TextField(controller: passCtrl, decoration: const InputDecoration(labelText: 'Password'), obscureText: true),
            const SizedBox(height: 8),
            DropdownButtonFormField<String>(
              value: role,
              items: const [
                DropdownMenuItem(value: 'driver', child: Text('Driver')),
                DropdownMenuItem(value: 'rider', child: Text('Rider')),
                DropdownMenuItem(value: 'teacher', child: Text('Teacher')),
              ],
              onChanged: (v) => setState(() => role = v ?? 'rider'),
            ),
            const SizedBox(height: 8),
            const Text(roleSelectionNote),
            const SizedBox(height: 12),
            ElevatedButton(
              onPressed: (!otpVerified || auth.loading)
                  ? null
                  : () async {
                      await ref.read(authControllerProvider.notifier).register(
                            email: emailCtrl.text.trim(),
                            fullName: nameCtrl.text.trim(),
                            password: passCtrl.text,
                            role: role,
                          );
                      if (mounted) Navigator.pop(context);
                    },
              child: const Text('Register'),
            ),
            if (info.isNotEmpty) Text(info),
            if (auth.error != null) Text(auth.error!, style: const TextStyle(color: Colors.red)),
          ],
        ),
      ),
    );
  }
}
