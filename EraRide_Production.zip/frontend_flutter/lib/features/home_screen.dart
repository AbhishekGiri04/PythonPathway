import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'admin/admin_screen.dart';
import 'auth/auth_controller.dart';
import 'chat/chat_screen.dart';
import 'bookings/my_bookings_screen.dart';
import 'profile/profile_screen.dart';
import 'rides/driver_ride_screen.dart';
import 'rides/rides_screen.dart';
import 'teacher/teacher_complaint_screen.dart';

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final user = ref.watch(authControllerProvider).user;
    if (user == null) {
      return const SizedBox.shrink();
    }

    final role = user.role;

    final pages = <Widget>[
      if (role == 'driver') const DriverRideScreen(),
      if (role == 'rider') const RidesScreen(),
      if (role == 'rider') const MyBookingsScreen(),
      if (role == 'teacher') const TeacherComplaintScreen(),
      if (role == 'admin') const AdminScreen(),
      const ChatScreen(),
      const ProfileScreen(),
    ];

    return DefaultTabController(
      length: pages.length,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('EraRide'),
          bottom: TabBar(
            isScrollable: true,
            tabs: [
              if (role == 'driver') const Tab(text: 'Driver'),
              if (role == 'rider') const Tab(text: 'Rides'),
              if (role == 'rider') const Tab(text: 'Bookings'),
              if (role == 'teacher') const Tab(text: 'Complaints'),
              if (role == 'admin') const Tab(text: 'Admin'),
              const Tab(text: 'Chat'),
              const Tab(text: 'Profile'),
            ],
          ),
        ),
        body: TabBarView(children: pages),
      ),
    );
  }
}
