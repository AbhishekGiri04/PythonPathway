import 'dart:convert';

import 'package:web_socket_channel/web_socket_channel.dart';

class ChatService {
  WebSocketChannel connect({required int roomId, required String token}) {
    final uri = Uri.parse('ws://10.0.2.2:8000/api/v1/chat/ws/$roomId?token=$token');
    return WebSocketChannel.connect(uri);
  }

  Map<String, dynamic> decode(dynamic event) => jsonDecode(event as String) as Map<String, dynamic>;
}
