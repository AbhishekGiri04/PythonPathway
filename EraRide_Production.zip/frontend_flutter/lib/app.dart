import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'core/theme.dart';
import 'features/auth/auth_controller.dart';
import 'features/auth/login_screen.dart';
import 'features/auth/otp_register_screen.dart';
import 'features/home_screen.dart';

class EraRideApp extends ConsumerStatefulWidget {
  const EraRideApp({super.key});

  @override
  ConsumerState<EraRideApp> createState() => _EraRideAppState();
}

class _EraRideAppState extends ConsumerState<EraRideApp> {
  @override
  void initState() {
    super.initState();
    Future.microtask(() => ref.read(authControllerProvider.notifier).bootstrap());
  }

  @override
  Widget build(BuildContext context) {
    final auth = ref.watch(authControllerProvider);

    return MaterialApp(
      title: 'EraRide',
      theme: buildTheme(),
      routes: {
        '/otp': (_) => const OtpRegisterScreen(),
      },
      home: auth.user == null ? const LoginScreen() : const HomeScreen(),
    );
  }
}
