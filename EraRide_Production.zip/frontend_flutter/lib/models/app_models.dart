class AppUser {
  final int id;
  final String email;
  final String role;
  final String token;

  AppUser({required this.id, required this.email, required this.role, required this.token});
}

class Ride {
  final int id;
  final int driverId;
  final String fromArea;
  final String toCampus;
  final String departureTime;
  final int availableSeats;
  final int totalSeats;
  final double pricePerSeat;

  Ride({
    required this.id,
    required this.driverId,
    required this.fromArea,
    required this.toCampus,
    required this.departureTime,
    required this.availableSeats,
    required this.totalSeats,
    required this.pricePerSeat,
  });

  factory Ride.fromJson(Map<String, dynamic> json) => Ride(
        id: json['id'] as int,
        driverId: json['driver_id'] as int,
        fromArea: json['from_area'] as String,
        toCampus: json['to_campus'] as String,
        departureTime: json['departure_time'] as String,
        availableSeats: json['available_seats'] as int,
        totalSeats: json['total_seats'] as int,
        pricePerSeat: (json['price_per_seat'] as num).toDouble(),
      );
}
